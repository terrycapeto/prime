__title__ = 'amazoncaptcha'
__description__ = "Pure Python, lightweight, Pillow-based solver for the Amazon text captcha."
__url__ = 'https://github.com/a-maliarov/amazoncaptcha'
__version__ = '0.5.11'
__author__ = 'Anatolii Maliarov'
__author_email__ = 'tly.mov@gmail.com'
__license__ = 'MIT'
__copyright__ = 'Copyright 2020 Anatolii Maliarov'
