__title__ = 'MechanicalSoup'
__description__ = 'A Python library for automating interaction with websites'
__url__ = 'https://mechanicalsoup.readthedocs.io/'
__github_url__ = 'https://github.com/MechanicalSoup/MechanicalSoup'
__version__ = '1.0.0'
__license__ = 'MIT'
__github_assets_absoluteURL__ = """\
https://raw.githubusercontent.com/MechanicalSoup/MechanicalSoup/master"""
